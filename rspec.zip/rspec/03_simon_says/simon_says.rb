#write your code here
def echo (name)
   return name
end
def shout(xxx)
    return xxx.upcase
end
def repeat(word,b=2)
    word = [word]
    word*=b
    return word.join(" ")
end