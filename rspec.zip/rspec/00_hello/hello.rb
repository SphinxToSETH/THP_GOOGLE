#write your code here

def hello
   return "Hello!"
end
def greet(hard)
    "Hello, #{hard}!"
end
